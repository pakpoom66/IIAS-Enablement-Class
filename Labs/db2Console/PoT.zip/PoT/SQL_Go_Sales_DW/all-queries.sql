--IIAS GO Sales SQL Demo - QUERIES
--set schema to POTUSER01 for years 1 - 3 and GOSALESHS for years 1 - 5
--Query 1: Select all rows from EMP_EXPENSE_FACT
--Query 2: Count EMP_EXPENSE_FACT grouped by organization
--Query 3: Select sales from SLS_SALES_FACT where quantity sold over 9000 units
--Query 4: Four table join to select the records order method where lang is english
--Query 5: Count records of a four table join to count the records order method where lang is english
--Query 6: Find out which purchase method of all the methods has the greatest quantity of orders
--Query 7: Show the products by its product key, by the number of units that were shipped, and by the number of units that were sold, rank the top products

set schema GOSALESDW;

--Query 1: Select all rows from EMP_EXPENSE_FACT
SELECT * FROM EMP_EXPENSE_FACT fetch first 10 rows only;


--Query 2: Count EMP_EXPENSE_FACT grouped by organization
SELECT ORGANIZATION_KEY, COUNT(*) AS "Row Count" 
FROM EMP_EXPENSE_FACT 
GROUP BY ORGANIZATION_KEY 
ORDER BY ORGANIZATION_KEY;

--Query 3: Select sales from SLS_SALES_FACT where quantity sold over 9000 units
SELECT CLOSE_DAY_KEY, EMPLOYEE_KEY, GROSS_MARGIN, GROSS_PROFIT, ORDER_DAY_KEY,
ORDER_METHOD_KEY, ORGANIZATION_KEY, PRODUCT_KEY, PROMOTION_KEY, QUANTITY, RETAILER_KEY
RETAILER_SITE_KEY, SALES_ORDER_KEY, SALE_TOTAL, SHIP_DAY_KEY, UNIT_COST, UNIT_PRICE, UNIT_SALE_PRICE
FROM SLS_SALES_FACT
WHERE QUANTITY > 9000
ORDER BY GROSS_PROFIT DESC;


--Query 4: Four table join to select the records order method where lang is english
SELECT pnumb.product_name, sales.quantity, 
  meth.order_method_en
FROM 
  sls_sales_fact sales, 
  sls_product_dim prod, 
  sls_product_lookup pnumb, 
  sls_order_method_dim meth
WHERE 
  pnumb.product_language='EN'
  AND sales.product_key=prod.product_key 
  AND prod.product_number=pnumb.product_number 
  AND meth.order_method_key=sales.order_method_key fetch first 10 rows only;
  
--Query 5: Count records of a four table join to count the records order method where lang is english
SELECT COUNT(*)  
--(SELECT pnumb.product_name, sales.quantity, 
--  meth.order_method_en
FROM 
 sls_sales_fact sales, 
 sls_product_dim prod, 
 sls_product_lookup pnumb, 
 sls_order_method_dim meth
WHERE 
 pnumb.product_language='EN'
 AND sales.product_key=prod.product_key 
 AND prod.product_number=pnumb.product_number 
 AND meth.order_method_key=sales.order_method_key;
 

--Query 6: Find out which purchase method of all the methods has the greatest quantity of orders 
SELECT  pll.product_line_en AS Product,  
     md.order_method_en AS Order_method,
     SUM(sf.QUANTITY) AS total             
FROM sls_order_method_dim AS md,
     sls_product_dim AS pd,
     sls_product_line_lookup AS pll,
     sls_product_brand_lookup AS pbl,
     sls_sales_fact AS sf
WHERE 
     pd.product_key = sf.product_key
     AND md.order_method_key = sf.order_method_key
            AND pll.product_line_code = pd.product_line_code
            AND pbl.product_brand_code = pd.product_brand_code 
GROUP BY pll.product_line_en, md.order_method_en;  

--Query 7: Show the products by its product key, by the number of units that were shipped, and by the number of units that were sold.
WITH
 sales AS
 (SELECT sf.*
  FROM sls_order_method_dim AS md,
       sls_product_dim AS pd, 
       emp_employee_dim AS ed,
       sls_sales_fact AS sf
  WHERE pd.product_key = sf.product_key  
    AND pd.product_number > 10000
    AND pd.base_product_key > 30 
    AND md.order_method_key = sf.order_method_key 
    AND md.order_method_code > 5 
    AND ed.employee_key = sf.employee_key 
    AND ed.manager_code1 > 20),
 inventory AS
 (SELECT if.*
  FROM go_branch_dim AS bd, 
    dist_inventory_fact AS if
  WHERE if.branch_key = bd.branch_key 
    AND bd.branch_code > 20)
SELECT sales.product_key AS PROD_KEY, 
 SUM(CAST (inventory.quantity_shipped AS BIGINT)) AS INV_SHIPPED,
 SUM(CAST (sales.quantity AS BIGINT)) AS PROD_QUANTITY, 
 RANK() OVER ( ORDER BY SUM(CAST (sales.quantity AS BIGINT)) DESC) AS PROD_RANK
FROM sales, inventory
 WHERE sales.product_key = inventory.product_key
GROUP BY sales.product_key;
--End of IIAS GO Sales SQL Demo - QUERIES

