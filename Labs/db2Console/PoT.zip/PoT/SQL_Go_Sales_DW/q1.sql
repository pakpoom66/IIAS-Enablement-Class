set schema GOSALESDW;

--Query 1: Select all rows from EMP_EXPENSE_FACT
SELECT * FROM EMP_EXPENSE_FACT fetch first 5 rows only;
