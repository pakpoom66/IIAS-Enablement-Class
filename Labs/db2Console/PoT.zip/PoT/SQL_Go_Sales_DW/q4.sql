set schema GOSALESDW;

--Query 4: Four table join to select the records order method where lang is english
SELECT pnumb.product_name, sales.quantity, 
  meth.order_method_en
FROM 
  sls_sales_fact sales, 
  sls_product_dim prod, 
  sls_product_lookup pnumb, 
  sls_order_method_dim meth
WHERE 
  pnumb.product_language='EN'
  AND sales.product_key=prod.product_key 
  AND prod.product_number=pnumb.product_number 
  AND meth.order_method_key=sales.order_method_key
fetch first 50 rows only;
