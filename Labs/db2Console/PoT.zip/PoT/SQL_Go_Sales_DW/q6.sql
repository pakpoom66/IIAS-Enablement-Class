set schema GOSALESDW;

--Query 6: Find out which purchase method of all the methods has the greatest quantity of orders 
SELECT  pll.product_line_en AS Product,  
     md.order_method_en AS Order_method,
     SUM(sf.QUANTITY) AS total             
FROM sls_order_method_dim AS md,
     sls_product_dim AS pd,
     sls_product_line_lookup AS pll,
     sls_product_brand_lookup AS pbl,
     sls_sales_fact AS sf
WHERE 
     pd.product_key = sf.product_key
     AND md.order_method_key = sf.order_method_key
            AND pll.product_line_code = pd.product_line_code
            AND pbl.product_brand_code = pd.product_brand_code 
GROUP BY pll.product_line_en, md.order_method_en;  
